import { redirect } from 'next/navigation';

export default function RootPage() {
  // middleware.ts already gates this on auth; land signed-in visitors on
  // the dashboard by default.
  redirect('/dashboard');
}
