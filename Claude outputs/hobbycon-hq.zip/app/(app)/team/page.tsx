import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { TeamManager } from '@/components/TeamManager';

export default async function TeamPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: me } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (me?.role !== 'admin') redirect('/dashboard');

  const { data: profiles } = await supabase.from('profiles').select('*').order('created_at', { ascending: true });

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-[19px] font-extrabold">Team</h1>
        <p className="mt-0.5 text-[12.5px] text-text-muted">Invite teammates and manage who's an admin. Admins-only page.</p>
      </header>
      <TeamManager initialProfiles={profiles || []} currentUserId={user.id} />
    </div>
  );
}
