import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { Sidebar } from '@/components/Sidebar';

// Shell for every authenticated page: sidebar nav + main content area.
// middleware.ts already redirects signed-out visitors to /login, so by the
// time we're here `user` should exist — but we still fetch the profile
// (for role-gated nav) and re-check, since a race on first sign-in is cheap
// to guard against.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single();

  return (
    <div className="flex min-h-screen">
      <Sidebar email={profile?.email ?? user.email ?? ''} role={profile?.role ?? 'member'} />
      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-6xl px-7 py-7">{children}</div>
      </main>
    </div>
  );
}
