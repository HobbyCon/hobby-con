import { createClient } from '@/lib/supabase/server';
import { Dashboard } from '@/components/Dashboard';

export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-[19px] font-extrabold">Dashboard</h1>
        <p className="mt-0.5 text-[12.5px] text-text-muted">Where the vendor fair, the grant pipeline, and the content calendar stand today.</p>
      </header>
      <Dashboard userId={user!.id} />
    </div>
  );
}
