import { createClient } from '@/lib/supabase/server';
import { TaskBoard } from '@/components/TaskBoard';

export default async function TasksPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-[19px] font-extrabold">Tasks</h1>
        <p className="mt-0.5 text-[12.5px] text-text-muted">Everything the team is planning, grouped by status. Drag a card to move it.</p>
      </header>
      <TaskBoard userId={user!.id} />
    </div>
  );
}
