import { createClient } from '@/lib/supabase/server';
import { ContentCalendar } from '@/components/ContentCalendar';

export default async function ContentPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-[19px] font-extrabold">Content calendar</h1>
        <p className="mt-0.5 text-[12.5px] text-text-muted">What's going out, where, and when — across the channels HobbyCon posts to.</p>
      </header>
      <ContentCalendar userId={user!.id} />
    </div>
  );
}
