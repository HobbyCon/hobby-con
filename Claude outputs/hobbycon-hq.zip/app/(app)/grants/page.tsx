import { createClient } from '@/lib/supabase/server';
import { GrantsBoard } from '@/components/GrantsBoard';

export default async function GrantsPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div>
      <header className="mb-5">
        <h1 className="font-display text-[19px] font-extrabold">Grants</h1>
        <p className="mt-0.5 text-[12.5px] text-text-muted">The funding pipeline: who we've applied to and where each stands.</p>
      </header>
      <GrantsBoard userId={user!.id} />
    </div>
  );
}
