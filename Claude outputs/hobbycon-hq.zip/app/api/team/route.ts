import { NextResponse } from 'next/server';
import { createClient, createAdminClient } from '@/lib/supabase/server';

async function requireAdmin() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: NextResponse.json({ error: 'Not signed in.' }, { status: 401 }) };
  const { data: me } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (me?.role !== 'admin') return { error: NextResponse.json({ error: 'Admins only.' }, { status: 403 }) };
  return { supabase, userId: user.id };
}

// Change a teammate's role (admin/member).
export async function PATCH(request: Request) {
  const auth = await requireAdmin();
  if (auth.error) return auth.error;

  const { id, role } = await request.json();
  if (!id || !['admin', 'member'].includes(role)) {
    return NextResponse.json({ error: 'id and a valid role are required.' }, { status: 400 });
  }
  if (id === auth.userId && role !== 'admin') {
    return NextResponse.json({ error: "You can't remove your own admin access." }, { status: 400 });
  }

  const { error } = await auth.supabase!.from('profiles').update({ role }).eq('id', id);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}

// Remove a teammate entirely (deletes their auth user; profiles row cascades).
export async function DELETE(request: Request) {
  const auth = await requireAdmin();
  if (auth.error) return auth.error;

  const { id } = await request.json();
  if (!id) return NextResponse.json({ error: 'id is required.' }, { status: 400 });
  if (id === auth.userId) return NextResponse.json({ error: "You can't remove yourself." }, { status: 400 });

  const admin = createAdminClient();
  const { error } = await admin.auth.admin.deleteUser(id);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
