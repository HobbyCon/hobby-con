import { NextResponse } from 'next/server';
import { createClient, createAdminClient } from '@/lib/supabase/server';

// Admin-only: invite a teammate by email. Supabase sends them an email with
// a sign-in link; landing on /auth/callback exchanges it for a session, and
// the handle_new_user() trigger (see supabase/migrations/0001_init.sql)
// creates their profiles row automatically with role='member'.
export async function POST(request: Request) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Not signed in.' }, { status: 401 });

  const { data: me } = await supabase.from('profiles').select('role').eq('id', user.id).single();
  if (me?.role !== 'admin') return NextResponse.json({ error: 'Admins only.' }, { status: 403 });

  const { email, full_name } = await request.json();
  if (!email || typeof email !== 'string') return NextResponse.json({ error: 'Email is required.' }, { status: 400 });

  const admin = createAdminClient();
  const { error } = await admin.auth.admin.inviteUserByEmail(email, {
    data: full_name ? { full_name } : undefined,
    redirectTo: `${new URL(request.url).origin}/auth/callback`,
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
