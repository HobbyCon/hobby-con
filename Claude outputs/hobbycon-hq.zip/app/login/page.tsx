'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';

// Invite-only: there's no "create account" link here on purpose. An admin
// invites a teammate from /team, Supabase emails them a sign-in link, and
// they land here already provisioned — this form is just how they sign
// back in later (magic link, no password to manage).
export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('sending');
    setError('');
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: `${window.location.origin}/auth/callback` },
    });
    if (error) {
      setStatus('error');
      setError(error.message);
      return;
    }
    setStatus('sent');
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-bg px-4">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-surface p-8 shadow-md2">
        <div className="mb-6 flex items-center gap-3">
          <div
            className="flex h-9 w-9 flex-none items-center justify-center rounded-[10px] font-display text-[15px] font-extrabold text-[#2a1450] shadow-sm2"
            style={{ background: 'linear-gradient(135deg, var(--grad-a), var(--grad-b))' }}
          >
            HC
          </div>
          <div>
            <p className="font-display text-[15px] font-extrabold leading-tight text-text">HobbyCon HQ</p>
            <p className="text-[11px] font-medium text-text-muted">Team workspace</p>
          </div>
        </div>

        {status === 'sent' ? (
          <div className="rounded-lg border border-status-done/30 bg-[var(--status-done-bg)] p-4 text-[13px] font-medium text-[var(--status-done)]">
            Check <strong>{email}</strong> for a sign-in link.
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-[11px] font-bold uppercase tracking-wide text-text-muted">
                Work email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@hobbycon.com"
                className="rounded-lg border border-border-strong bg-surface-2 px-3 py-2 text-[13px] text-text outline-none focus-visible:ring-2 focus-visible:ring-accent"
              />
            </div>
            <button
              type="submit"
              disabled={status === 'sending'}
              className="mt-1 rounded-lg bg-accent px-4 py-2.5 text-[13px] font-bold text-white transition hover:bg-accent-strong disabled:opacity-60"
            >
              {status === 'sending' ? 'Sending link…' : 'Send sign-in link'}
            </button>
            {status === 'error' && <p className="text-[12px] font-medium text-status-crit">{error}</p>}
            <p className="mt-1 text-[11.5px] leading-relaxed text-text-muted">
              This workspace is invite-only. If you haven’t been invited yet, ask a HobbyCon HQ admin to add you from the Team page.
            </p>
          </form>
        )}
      </div>
    </main>
  );
}
