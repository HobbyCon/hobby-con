import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

// Supabase magic-link and invite emails redirect here with a `code` param.
// Exchanging it sets the auth cookie, then we send the person into the app.
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');

  if (code) {
    const supabase = createClient();
    await supabase.auth.exchangeCodeForSession(code);
  }

  return NextResponse.redirect(`${origin}/dashboard`);
}
