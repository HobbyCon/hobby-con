import type { Metadata } from 'next';
import './globals.css';

// Loaded via a plain <link> rather than next/font/google: next/font fetches
// and self-hosts font files at *build* time, which fails in any build
// environment without outbound access to fonts.googleapis.com. A <link>
// resolves in the visitor's browser at request time instead — same fonts,
// no build-time network dependency. Swap to next/font later if you'd rather
// self-host.
export const metadata: Metadata = {
  title: 'HobbyCon HQ',
  description: 'HobbyCon’s internal team workspace — tasks, content calendar, and grants.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800&family=Public+Sans:wght@400;500;600;700&display=swap"
        />
      </head>
      <body className="font-sans text-sm">{children}</body>
    </html>
  );
}
