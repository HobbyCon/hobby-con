-- HobbyCon HQ — initial schema, roles, and row-level security.
-- Run this once against your Supabase project (SQL Editor, or `supabase db push`).

-- ---------------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------------
create extension if not exists "pgcrypto"; -- gen_random_uuid()

-- ---------------------------------------------------------------------------
-- Profiles — one row per team member, extends auth.users with a role.
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null,
  full_name text,
  role text not null default 'member' check (role in ('admin', 'member')),
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever a new auth user is created (e.g. via an
-- admin invite). New members default to 'member'; promote via the Team page.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data ->> 'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Work tables
-- ---------------------------------------------------------------------------
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  module text not null default 'general' check (module in ('vendor-fair', 'funding', 'content', 'general')),
  status text not null default 'todo' check (status in ('todo', 'doing', 'done')),
  assignee text,
  due_date date,
  notes text,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.content_posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  platform text not null default 'instagram' check (platform in ('instagram', 'facebook', 'tiktok', 'email')),
  status text not null default 'idea' check (status in ('idea', 'drafting', 'scheduled', 'posted')),
  scheduled_date date,
  link text,
  notes text,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.grants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  amount text,
  deadline date,
  status text not null default 'researching' check (status in ('researching', 'drafting', 'submitted', 'awarded', 'declined')),
  notes text,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.metrics (
  id uuid primary key default gen_random_uuid(),
  period text not null,
  category text not null,
  metric text not null,
  value numeric not null,
  created_by uuid references public.profiles (id) on delete set null,
  created_at timestamptz not null default now()
);

-- updated_at maintenance
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_updated_at on public.tasks;
create trigger set_updated_at before update on public.tasks
  for each row execute function public.set_updated_at();

drop trigger if exists set_updated_at on public.content_posts;
create trigger set_updated_at before update on public.content_posts
  for each row execute function public.set_updated_at();

drop trigger if exists set_updated_at on public.grants;
create trigger set_updated_at before update on public.grants
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Row Level Security
-- Model: any signed-in team member (has a profiles row) can read everything
-- and create/edit anything. Deleting is restricted to admins or the row's
-- own creator. Only admins can change roles or see the full team list write
-- path (reads are open so the app can show a team directory).
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.content_posts enable row level security;
alter table public.grants enable row level security;
alter table public.metrics enable row level security;

create or replace function public.is_team_member()
returns boolean language sql security definer stable as $$
  select exists (select 1 from public.profiles where id = auth.uid());
$$;

create or replace function public.is_admin()
returns boolean language sql security definer stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- profiles
create policy "team can read profiles" on public.profiles
  for select using (public.is_team_member());
create policy "users can update own name" on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());
create policy "admins can update any profile" on public.profiles
  for update using (public.is_admin());
create policy "admins can remove profiles" on public.profiles
  for delete using (public.is_admin());

-- generic helper pattern applied to each work table
create policy "team can read tasks" on public.tasks for select using (public.is_team_member());
create policy "team can insert tasks" on public.tasks for insert with check (public.is_team_member());
create policy "team can update tasks" on public.tasks for update using (public.is_team_member());
create policy "owner or admin can delete tasks" on public.tasks for delete
  using (public.is_admin() or created_by = auth.uid());

create policy "team can read content" on public.content_posts for select using (public.is_team_member());
create policy "team can insert content" on public.content_posts for insert with check (public.is_team_member());
create policy "team can update content" on public.content_posts for update using (public.is_team_member());
create policy "owner or admin can delete content" on public.content_posts for delete
  using (public.is_admin() or created_by = auth.uid());

create policy "team can read grants" on public.grants for select using (public.is_team_member());
create policy "team can insert grants" on public.grants for insert with check (public.is_team_member());
create policy "team can update grants" on public.grants for update using (public.is_team_member());
create policy "owner or admin can delete grants" on public.grants for delete
  using (public.is_admin() or created_by = auth.uid());

create policy "team can read metrics" on public.metrics for select using (public.is_team_member());
create policy "team can insert metrics" on public.metrics for insert with check (public.is_team_member());
create policy "owner or admin can delete metrics" on public.metrics for delete
  using (public.is_admin() or created_by = auth.uid());

-- ---------------------------------------------------------------------------
-- Seed: known HobbyCon context (vendor-fair planning + grant pipeline).
-- created_by is left null here — these predate any specific team member —
-- and public sign-up must be disabled in Supabase Auth (Authentication →
-- Providers → Email → disable "Allow new users to sign up") so the app
-- stays invite-only; the first admin is set by hand after your first login,
-- see README.
-- ---------------------------------------------------------------------------
insert into public.tasks (title, module, status, notes) values
  ('Compare venue options: NYC Parks, DOT plazas, private lots, beer gardens', 'vendor-fair', 'todo', 'Targeting ~50 tables, outdoor, NYC.'),
  ('Resolve permitting requirements for a ~50-table outdoor vendor fair', 'vendor-fair', 'todo', null),
  ('Determine nonprofit / fiscal sponsorship status', 'vendor-fair', 'todo', 'Gates venue pricing and eligibility.'),
  ('Decide target borough(s)', 'vendor-fair', 'todo', 'Gates venue pricing and eligibility.')
on conflict do nothing;

insert into public.grants (name, status, notes) values
  ('Amber Grant', 'researching', 'Priority application.'),
  ('HerRise Microgrant', 'researching', 'Priority application.'),
  ('IFundWomen', 'researching', 'Priority application.')
on conflict do nothing;

insert into public.content_posts (title, platform, status, notes) values
  ('Promote: Trivia Night — Sep 14', 'instagram', 'idea', 'From the events calendar on hobbycon.com.'),
  ('Promote: Food Crawl — Sep 19', 'instagram', 'idea', 'From the events calendar on hobbycon.com.'),
  ('Promote: Speed Puzzle League — Oct 1', 'instagram', 'idea', 'From the events calendar on hobbycon.com.'),
  ('Promote: Photography — Oct 10', 'instagram', 'idea', 'From the events calendar on hobbycon.com.'),
  ('Promote: Craft — Oct 12', 'instagram', 'idea', 'From the events calendar on hobbycon.com.')
on conflict do nothing;

-- ---------------------------------------------------------------------------
-- Realtime — lets every open browser tab see teammates' changes live via
-- Supabase's postgres_changes subscriptions (see components/*.tsx).
-- ---------------------------------------------------------------------------
do $$
begin
  alter publication supabase_realtime add table public.tasks;
exception when duplicate_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.content_posts;
exception when duplicate_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.grants;
exception when duplicate_object then null;
end $$;
do $$
begin
  alter publication supabase_realtime add table public.metrics;
exception when duplicate_object then null;
end $$;
