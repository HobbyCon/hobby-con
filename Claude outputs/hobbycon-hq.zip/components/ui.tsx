export function StatusPill({ label, fg, bg, border }: { label: string; fg: string; bg: string; border: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[11px] font-bold"
      style={{ color: fg, background: bg, borderColor: border }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: 'currentColor' }} />
      {label}
    </span>
  );
}

export function Tag({ label, fg, bg, border }: { label: string; fg: string; bg: string; border: string }) {
  return (
    <span className="inline-flex items-center rounded-full border px-2 py-0.5 text-[10.5px] font-bold" style={{ color: fg, background: bg, borderColor: border }}>
      {label}
    </span>
  );
}

export function EmptyState({ title, sub }: { title: string; sub: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border-strong bg-surface-2 px-5 py-8 text-center">
      <strong className="block text-[14px] text-text-secondary">{title}</strong>
      <span className="text-[13px] text-text-muted">{sub}</span>
    </div>
  );
}

export function Card({ title, sub, children }: { title: string; sub?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-surface p-[18px] shadow-sm2">
      <h2 className="text-[14px] font-bold">{title}</h2>
      {sub && <p className="mb-3.5 mt-0.5 text-[11.5px] text-text-muted">{sub}</p>}
      {children}
    </div>
  );
}

export function StatTile({ label, value, sub }: { label: string; value: number | string; sub: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface px-4 py-3.5 shadow-sm2">
      <div className="text-[11px] font-bold uppercase tracking-wide text-text-muted">{label}</div>
      <div className="font-display mt-1 text-[26px] font-extrabold tabular-nums">{value}</div>
      <div className="mt-0.5 text-[11.5px] text-text-muted">{sub}</div>
    </div>
  );
}

export function IconBtn({ onClick, label, children }: { onClick: () => void; label: string; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      title={label}
      className="rounded-[5px] p-1 text-text-muted transition hover:bg-[var(--status-crit-bg)] hover:text-status-crit"
    >
      {children}
    </button>
  );
}

export function TrashIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
      <path d="M4 6h12M8 6V4.5A1.5 1.5 0 0 1 9.5 3h1A1.5 1.5 0 0 1 12 4.5V6m-6 0 .6 10.2A1.5 1.5 0 0 0 8.1 17.5h3.8a1.5 1.5 0 0 0 1.5-1.3L14 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Btn({
  children,
  onClick,
  type = 'button',
  variant = 'default',
  className = '',
}: {
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit';
  variant?: 'default' | 'primary' | 'ghost';
  className?: string;
}) {
  const base = 'inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-[12.5px] font-bold transition active:translate-y-px';
  const styles = {
    default: 'border border-border-strong bg-surface text-text hover:shadow-sm2',
    primary: 'bg-accent text-white hover:bg-accent-strong',
    ghost: 'text-text-muted hover:bg-surface-2 hover:text-text',
  }[variant];
  return (
    <button type={type} onClick={onClick} className={`${base} ${styles} ${className}`}>
      {children}
    </button>
  );
}
