'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { GRANT_STATUSES, fmtDate, statusMeta } from '@/lib/constants';
import { Btn, EmptyState, IconBtn, StatusPill, TrashIcon } from '@/components/ui';
import type { Grant, GrantStatus } from '@/lib/types';

export function GrantsBoard({ userId }: { userId: string }) {
  const supabase = useMemo(() => createClient(), []);
  const [grants, setGrants] = useState<Grant[]>([]);
  const [loading, setLoading] = useState(true);
  const [openForm, setOpenForm] = useState(false);

  useEffect(() => {
    let active = true;
    supabase
      .from('grants')
      .select('*')
      .then(({ data }) => {
        if (active && data) setGrants(data as Grant[]);
        setLoading(false);
      });

    const channel = supabase
      .channel('grants-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'grants' }, (payload) => {
        setGrants((prev) => {
          if (payload.eventType === 'INSERT') return prev.some((g) => g.id === (payload.new as Grant).id) ? prev : [...prev, payload.new as Grant];
          if (payload.eventType === 'UPDATE') return prev.map((g) => (g.id === (payload.new as Grant).id ? (payload.new as Grant) : g));
          if (payload.eventType === 'DELETE') return prev.filter((g) => g.id !== (payload.old as Grant).id);
          return prev;
        });
      })
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [supabase]);

  async function addGrant(form: FormData) {
    const draft = {
      name: String(form.get('name') || ''),
      amount: String(form.get('amount') || '') || null,
      deadline: String(form.get('deadline') || '') || null,
      status: String(form.get('status') || 'researching') as GrantStatus,
      notes: String(form.get('notes') || '') || null,
      created_by: userId,
    };
    setOpenForm(false);
    await supabase.from('grants').insert(draft);
  }

  async function setStatus(id: string, status: GrantStatus) {
    setGrants((prev) => prev.map((g) => (g.id === id ? { ...g, status } : g)));
    await supabase.from('grants').update({ status }).eq('id', id);
  }

  async function removeGrant(id: string) {
    setGrants((prev) => prev.filter((g) => g.id !== id));
    await supabase.from('grants').delete().eq('id', id);
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        <Btn variant="primary" onClick={() => setOpenForm((v) => !v)}>
          {openForm ? 'Cancel' : '+ Add grant'}
        </Btn>
      </div>

      {openForm && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            addGrant(new FormData(e.currentTarget));
          }}
          className="mb-4 grid grid-cols-2 gap-2.5 rounded-xl border border-dashed border-border-strong bg-surface-2 p-3.5 md:grid-cols-4"
        >
          <input name="name" required placeholder="e.g. Amber Grant" className="col-span-2 rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-accent md:col-span-4" />
          <input name="amount" placeholder="Amount (optional)" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]" />
          <input name="deadline" type="date" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]" />
          <select name="status" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]">
            {GRANT_STATUSES.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
          <textarea name="notes" placeholder="Eligibility, contact, link, etc." className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]" />
          <div className="col-span-2 flex gap-2 md:col-span-4">
            <Btn type="submit" variant="primary">
              Add grant
            </Btn>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-[13px] text-text-muted">Loading grants…</p>
      ) : grants.length === 0 ? (
        <EmptyState title="No grants tracked yet" sub="Use “+ Add grant” above to start the pipeline." />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {grants.map((g) => {
            const status = statusMeta(GRANT_STATUSES, g.status);
            return (
              <div key={g.id} className="rounded-xl border border-border bg-surface p-3.5 shadow-sm2">
                <div className="mb-1.5 flex items-start justify-between gap-2">
                  <h3 className="text-[14px] font-bold leading-snug">{g.name}</h3>
                  <IconBtn label="Delete grant" onClick={() => removeGrant(g.id)}>
                    <TrashIcon />
                  </IconBtn>
                </div>
                <StatusPill label={status.label} fg={status.fg} bg={status.bg} border={status.border} />
                {g.amount && (
                  <div className="mt-2 text-[11.5px] text-text-muted">
                    <strong className="text-text-secondary">Amount:</strong> {g.amount}
                  </div>
                )}
                {g.deadline && (
                  <div className="mt-0.5 text-[11.5px] text-text-muted">
                    <strong className="text-text-secondary">Deadline:</strong> {fmtDate(g.deadline)}
                  </div>
                )}
                {g.notes && <div className="mt-0.5 text-[11.5px] text-text-muted">{g.notes}</div>}
                <select
                  value={g.status}
                  onChange={(e) => setStatus(g.id, e.target.value as GrantStatus)}
                  className="mt-2.5 w-auto rounded-md border border-border-strong bg-surface-2 px-2 py-1 text-[11.5px]"
                >
                  {GRANT_STATUSES.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
                </select>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
