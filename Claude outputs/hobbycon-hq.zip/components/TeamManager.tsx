'use client';

import { useState } from 'react';
import { Btn, IconBtn, Tag, TrashIcon } from '@/components/ui';
import type { Profile, Role } from '@/lib/types';

export function TeamManager({ initialProfiles, currentUserId }: { initialProfiles: Profile[]; currentUserId: string }) {
  const [profiles, setProfiles] = useState(initialProfiles);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'error'>('idle');
  const [error, setError] = useState('');

  async function invite(e: React.FormEvent) {
    e.preventDefault();
    setStatus('sending');
    setError('');
    const res = await fetch('/api/invite', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, full_name: name || undefined }),
    });
    const body = await res.json();
    if (!res.ok) {
      setStatus('error');
      setError(body.error || 'Something went wrong.');
      return;
    }
    setStatus('idle');
    setEmail('');
    setName('');
  }

  async function changeRole(id: string, role: Role) {
    const prev = profiles;
    setProfiles((p) => p.map((x) => (x.id === id ? { ...x, role } : x)));
    const res = await fetch('/api/team', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, role }),
    });
    if (!res.ok) setProfiles(prev);
  }

  async function remove(id: string) {
    const prev = profiles;
    setProfiles((p) => p.filter((x) => x.id !== id));
    const res = await fetch('/api/team', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    if (!res.ok) setProfiles(prev);
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="rounded-xl border border-border bg-surface p-[18px] shadow-sm2">
        <h2 className="text-[14px] font-bold">Invite a teammate</h2>
        <p className="mb-3.5 mt-0.5 text-[11.5px] text-text-muted">They'll get an email with a sign-in link. New invites start as Members — promote them below once they've joined.</p>
        <form onSubmit={invite} className="flex flex-wrap items-end gap-2.5">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-bold uppercase tracking-wide text-text-muted">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="teammate@hobbycon.com"
              className="rounded-md border border-border-strong bg-surface-2 px-2.5 py-2 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-accent"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[11px] font-bold uppercase tracking-wide text-text-muted">Name (optional)</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="First Last" className="rounded-md border border-border-strong bg-surface-2 px-2.5 py-2 text-[13px]" />
          </div>
          <Btn type="submit" variant="primary">
            {status === 'sending' ? 'Sending…' : 'Send invite'}
          </Btn>
        </form>
        {status === 'error' && <p className="mt-2 text-[12px] font-medium text-status-crit">{error}</p>}
      </div>

      <div className="rounded-xl border border-border bg-surface p-[18px] shadow-sm2">
        <h2 className="mb-3.5 text-[14px] font-bold">Team ({profiles.length})</h2>
        <div className="flex flex-col gap-2">
          {profiles.map((p) => (
            <div key={p.id} className="flex items-center justify-between gap-3 rounded-[10px] border border-border bg-surface-2 px-3 py-2.5">
              <div className="min-w-0">
                <div className="truncate text-[13px] font-bold">{p.full_name || p.email}</div>
                <div className="truncate text-[11.5px] text-text-muted">{p.email}</div>
              </div>
              <div className="flex flex-none items-center gap-2">
                <Tag label={p.role} fg="var(--accent-strong)" bg="var(--accent-soft)" border="var(--accent-soft)" />
                <select
                  value={p.role}
                  onChange={(e) => changeRole(p.id, e.target.value as Role)}
                  disabled={p.id === currentUserId}
                  className="rounded-md border border-border-strong bg-surface px-2 py-1 text-[11.5px] disabled:opacity-50"
                >
                  <option value="member">Member</option>
                  <option value="admin">Admin</option>
                </select>
                {p.id !== currentUserId && (
                  <IconBtn label="Remove from team" onClick={() => remove(p.id)}>
                    <TrashIcon />
                  </IconBtn>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
