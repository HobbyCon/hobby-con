'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { MODULES, TASK_STATUSES, fmtDate, todayISO } from '@/lib/constants';
import { Btn, EmptyState, IconBtn, StatusPill, Tag, TrashIcon } from '@/components/ui';
import type { Task, TaskModule, TaskStatus } from '@/lib/types';

export function TaskBoard({ userId }: { userId: string }) {
  const supabase = useMemo(() => createClient(), []);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | TaskModule>('all');
  const [openForm, setOpenForm] = useState<TaskStatus | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    supabase
      .from('tasks')
      .select('*')
      .order('created_at', { ascending: true })
      .then(({ data }) => {
        if (active && data) setTasks(data as Task[]);
        setLoading(false);
      });

    const channel = supabase
      .channel('tasks-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, (payload) => {
        setTasks((prev) => {
          if (payload.eventType === 'INSERT') return prev.some((t) => t.id === (payload.new as Task).id) ? prev : [...prev, payload.new as Task];
          if (payload.eventType === 'UPDATE') return prev.map((t) => (t.id === (payload.new as Task).id ? (payload.new as Task) : t));
          if (payload.eventType === 'DELETE') return prev.filter((t) => t.id !== (payload.old as Task).id);
          return prev;
        });
      })
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [supabase]);

  const filtered = filter === 'all' ? tasks : tasks.filter((t) => t.module === filter);

  async function addTask(status: TaskStatus, form: FormData) {
    const draft = {
      title: String(form.get('title') || ''),
      module: String(form.get('module') || 'general') as TaskModule,
      assignee: String(form.get('assignee') || '') || null,
      due_date: String(form.get('dueDate') || '') || null,
      notes: String(form.get('notes') || '') || null,
      status,
      created_by: userId,
    };
    setOpenForm(null);
    await supabase.from('tasks').insert(draft);
  }

  async function moveTask(id: string, status: TaskStatus) {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, status } : t)));
    await supabase.from('tasks').update({ status }).eq('id', id);
  }

  async function removeTask(id: string) {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    await supabase.from('tasks').delete().eq('id', id);
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-1.5">
        <FilterChip active={filter === 'all'} onClick={() => setFilter('all')}>
          All modules
        </FilterChip>
        {(Object.keys(MODULES) as TaskModule[]).map((m) => (
          <FilterChip key={m} active={filter === m} onClick={() => setFilter(m)}>
            {MODULES[m].label}
          </FilterChip>
        ))}
      </div>

      {loading ? (
        <p className="text-[13px] text-text-muted">Loading board…</p>
      ) : (
        <div className="grid grid-cols-1 gap-3.5 md:grid-cols-3">
          {TASK_STATUSES.map((status) => {
            const items = filtered.filter((t) => t.status === status.id);
            return (
              <div
                key={status.id}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  if (dragId) moveTask(dragId, status.id);
                }}
                className="rounded-xl border border-border bg-surface-2 p-3"
              >
                <div className="mb-2.5 flex items-center justify-between px-0.5">
                  <StatusPill label={status.label} fg={status.fg} bg={status.bg} border={status.border} />
                  <span className="rounded-full border border-border bg-surface px-2 text-[11px] font-bold text-text-muted tabular-nums">{items.length}</span>
                </div>

                {items.map((t) => {
                  const mod = MODULES[t.module];
                  const overdue = t.due_date && t.status !== 'done' && t.due_date < todayISO();
                  return (
                    <div
                      key={t.id}
                      draggable
                      onDragStart={() => setDragId(t.id)}
                      onDragEnd={() => setDragId(null)}
                      className="mb-2 cursor-grab rounded-[10px] border border-border bg-surface p-2.5 shadow-sm2 active:cursor-grabbing"
                    >
                      <div className="mb-1.5 flex items-start justify-between gap-1.5">
                        <Tag label={mod.label} fg={mod.fg} bg={mod.bg} border={mod.border} />
                        <IconBtn label="Delete task" onClick={() => removeTask(t.id)}>
                          <TrashIcon />
                        </IconBtn>
                      </div>
                      <div className="text-[13px] font-bold leading-snug">{t.title}</div>
                      {t.notes && <div className="mt-1 text-[11.5px] text-text-muted">{t.notes}</div>}
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <span className="text-[11px] font-semibold text-text-muted">{t.assignee || '—'}</span>
                        {t.due_date && (
                          <span className={`text-[11px] font-bold ${overdue ? 'text-status-crit' : ''}`}>
                            {overdue ? 'Overdue · ' : ''}
                            {fmtDate(t.due_date)}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}

                {openForm === status.id ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      addTask(status.id, new FormData(e.currentTarget));
                    }}
                    className="mt-1 grid grid-cols-2 gap-2 rounded-[10px] border border-dashed border-border-strong bg-surface p-2.5"
                  >
                    <input name="title" required placeholder="Title" className="col-span-2 rounded-md border border-border-strong bg-surface-2 px-2 py-1.5 text-[12.5px] outline-none focus-visible:ring-2 focus-visible:ring-accent" />
                    <select name="module" className="rounded-md border border-border-strong bg-surface-2 px-2 py-1.5 text-[12.5px]">
                      {(Object.keys(MODULES) as TaskModule[]).map((m) => (
                        <option key={m} value={m}>
                          {MODULES[m].label}
                        </option>
                      ))}
                    </select>
                    <input name="assignee" placeholder="Assignee" className="rounded-md border border-border-strong bg-surface-2 px-2 py-1.5 text-[12.5px]" />
                    <input name="dueDate" type="date" className="col-span-2 rounded-md border border-border-strong bg-surface-2 px-2 py-1.5 text-[12.5px]" />
                    <textarea name="notes" placeholder="Notes (optional)" className="col-span-2 rounded-md border border-border-strong bg-surface-2 px-2 py-1.5 text-[12.5px]" />
                    <div className="col-span-2 flex gap-2">
                      <Btn type="submit" variant="primary" className="text-[11.5px]">
                        Add card
                      </Btn>
                      <Btn variant="ghost" className="text-[11.5px]" onClick={() => setOpenForm(null)}>
                        Cancel
                      </Btn>
                    </div>
                  </form>
                ) : (
                  <button
                    onClick={() => setOpenForm(status.id)}
                    className="mt-1 w-full rounded-[9px] border border-dashed border-border-strong px-2.5 py-2 text-left text-[12px] font-bold text-text-muted transition hover:border-accent hover:bg-accent-soft hover:text-accent-strong"
                  >
                    + Add card
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {!loading && tasks.length === 0 && <div className="mt-3"><EmptyState title="No tasks yet" sub="Add your first card in any column above." /></div>}
    </div>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full border px-3 py-1 text-[12px] font-bold transition ${
        active ? 'border-[var(--accent-strong)] bg-accent-soft text-accent-strong' : 'border-border-strong bg-surface text-text-secondary'
      }`}
    >
      {children}
    </button>
  );
}
