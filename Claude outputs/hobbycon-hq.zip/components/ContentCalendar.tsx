'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { CONTENT_STATUSES, PLATFORMS, fmtDate, monthKey, statusMeta } from '@/lib/constants';
import { Btn, EmptyState, IconBtn, StatusPill, TrashIcon } from '@/components/ui';
import type { ContentPlatform, ContentPost } from '@/lib/types';

export function ContentCalendar({ userId }: { userId: string }) {
  const supabase = useMemo(() => createClient(), []);
  const [posts, setPosts] = useState<ContentPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | ContentPlatform>('all');
  const [openForm, setOpenForm] = useState(false);

  useEffect(() => {
    let active = true;
    supabase
      .from('content_posts')
      .select('*')
      .then(({ data }) => {
        if (active && data) setPosts(data as ContentPost[]);
        setLoading(false);
      });

    const channel = supabase
      .channel('content-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'content_posts' }, (payload) => {
        setPosts((prev) => {
          if (payload.eventType === 'INSERT') return prev.some((p) => p.id === (payload.new as ContentPost).id) ? prev : [...prev, payload.new as ContentPost];
          if (payload.eventType === 'UPDATE') return prev.map((p) => (p.id === (payload.new as ContentPost).id ? (payload.new as ContentPost) : p));
          if (payload.eventType === 'DELETE') return prev.filter((p) => p.id !== (payload.old as ContentPost).id);
          return prev;
        });
      })
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [supabase]);

  const filtered = (filter === 'all' ? posts : posts.filter((p) => p.platform === filter)).sort((a, b) =>
    (a.scheduled_date || '9999').localeCompare(b.scheduled_date || '9999')
  );

  const groups = new Map<string, ContentPost[]>();
  filtered.forEach((p) => {
    const key = monthKey(p.scheduled_date);
    groups.set(key, [...(groups.get(key) || []), p]);
  });

  async function addPost(form: FormData) {
    const draft = {
      title: String(form.get('title') || ''),
      platform: String(form.get('platform') || 'instagram') as ContentPlatform,
      status: String(form.get('status') || 'idea'),
      scheduled_date: String(form.get('scheduledDate') || '') || null,
      link: String(form.get('link') || '') || null,
      notes: String(form.get('notes') || '') || null,
      created_by: userId,
    };
    setOpenForm(false);
    await supabase.from('content_posts').insert(draft);
  }

  async function removePost(id: string) {
    setPosts((prev) => prev.filter((p) => p.id !== id));
    await supabase.from('content_posts').delete().eq('id', id);
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          <FilterChip active={filter === 'all'} onClick={() => setFilter('all')}>
            All platforms
          </FilterChip>
          {(Object.keys(PLATFORMS) as ContentPlatform[]).map((p) => (
            <FilterChip key={p} active={filter === p} onClick={() => setFilter(p)}>
              {PLATFORMS[p].label}
            </FilterChip>
          ))}
        </div>
        <Btn variant="primary" onClick={() => setOpenForm((v) => !v)}>
          {openForm ? 'Cancel' : '+ Add post'}
        </Btn>
      </div>

      {openForm && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            addPost(new FormData(e.currentTarget));
          }}
          className="mb-4 grid grid-cols-2 gap-2.5 rounded-xl border border-dashed border-border-strong bg-surface-2 p-3.5 md:grid-cols-4"
        >
          <input name="title" required placeholder="e.g. Announce trivia night" className="col-span-2 rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px] outline-none focus-visible:ring-2 focus-visible:ring-accent md:col-span-4" />
          <select name="platform" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]">
            {(Object.keys(PLATFORMS) as ContentPlatform[]).map((p) => (
              <option key={p} value={p}>
                {PLATFORMS[p].label}
              </option>
            ))}
          </select>
          <select name="status" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]">
            {CONTENT_STATUSES.map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
              </option>
            ))}
          </select>
          <input name="scheduledDate" type="date" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]" />
          <input name="link" placeholder="Link (optional)" className="rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px]" />
          <textarea name="notes" placeholder="Caption ideas, who's shooting it, etc." className="col-span-2 rounded-md border border-border-strong bg-surface px-2.5 py-2 text-[13px] md:col-span-4" />
          <div className="col-span-2 flex gap-2 md:col-span-4">
            <Btn type="submit" variant="primary">
              Add post
            </Btn>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-[13px] text-text-muted">Loading calendar…</p>
      ) : filtered.length === 0 ? (
        <EmptyState title="No posts in the calendar yet" sub="Use “+ Add post” above to plan your first one." />
      ) : (
        [...groups.entries()].map(([month, rows]) => (
          <div key={month} className="mb-5">
            <h3 className="mb-2 text-[12.5px] font-bold uppercase tracking-wide text-text-muted">{month}</h3>
            {rows.map((p) => {
              const plat = PLATFORMS[p.platform];
              const status = statusMeta(CONTENT_STATUSES, p.status);
              return (
                <div key={p.id} className="mb-1.5 grid grid-cols-[64px_10px_1fr_auto_auto] items-center gap-3 rounded-[10px] border border-border bg-surface p-2.5 px-3 shadow-sm2">
                  <div className="text-[12px] font-bold tabular-nums text-text-secondary">{p.scheduled_date ? fmtDate(p.scheduled_date) : '—'}</div>
                  <div className="h-2.5 w-2.5 rounded-[3px]" style={{ background: plat.color }} title={plat.label} />
                  <div className="min-w-0">
                    <div className="truncate text-[13px] font-bold">
                      {p.title} <span className="text-[11px] font-semibold text-text-muted">{plat.label}</span>
                    </div>
                    {p.notes && <div className="truncate text-[11.5px] text-text-muted">{p.notes}</div>}
                  </div>
                  <StatusPill label={status.label} fg={status.fg} bg={status.bg} border={status.border} />
                  <IconBtn label="Delete post" onClick={() => removePost(p.id)}>
                    <TrashIcon />
                  </IconBtn>
                </div>
              );
            })}
          </div>
        ))
      )}
    </div>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full border px-3 py-1 text-[12px] font-bold transition ${
        active ? 'border-[var(--accent-strong)] bg-accent-soft text-accent-strong' : 'border-border-strong bg-surface text-text-secondary'
      }`}
    >
      {children}
    </button>
  );
}
