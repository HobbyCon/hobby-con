'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import type { Role } from '@/lib/types';

const NAV = [
  { href: '/dashboard', label: 'Dashboard' },
  { href: '/tasks', label: 'Tasks' },
  { href: '/content', label: 'Content' },
  { href: '/grants', label: 'Grants' },
] as const;

export function Sidebar({ email, role }: { email: string; role: Role }) {
  const pathname = usePathname();
  const router = useRouter();

  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push('/login');
    router.refresh();
  }

  return (
    <aside className="sticky top-0 flex h-screen w-[232px] flex-none flex-col gap-5 border-r border-border p-4" style={{ background: 'var(--surface-2)' }}>
      <div className="flex items-center gap-2.5 px-1.5">
        <div
          className="flex h-8 w-8 flex-none items-center justify-center rounded-[10px] font-display text-[14px] font-extrabold text-[#2a1450] shadow-sm2"
          style={{ background: 'linear-gradient(135deg, var(--grad-a), var(--grad-b))' }}
        >
          HC
        </div>
        <div className="leading-tight">
          <p className="font-display text-[14px] font-extrabold">HobbyCon HQ</p>
          <p className="text-[11px] font-medium text-text-muted">Team workspace</p>
        </div>
      </div>

      <nav className="flex flex-col gap-0.5">
        {NAV.map((item) => {
          const active = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`rounded-[9px] px-2.5 py-2 text-[13.5px] font-semibold transition ${
                active ? 'bg-surface text-accent-strong shadow-sm2' : 'text-text-secondary hover:bg-accent-soft hover:text-text'
              }`}
            >
              {item.label}
            </Link>
          );
        })}
        {role === 'admin' && (
          <Link
            href="/team"
            className={`rounded-[9px] px-2.5 py-2 text-[13.5px] font-semibold transition ${
              pathname?.startsWith('/team') ? 'bg-surface text-accent-strong shadow-sm2' : 'text-text-secondary hover:bg-accent-soft hover:text-text'
            }`}
          >
            Team
          </Link>
        )}
      </nav>

      <div className="mt-auto flex flex-col gap-2 border-t border-border pt-3">
        <div className="px-1">
          <p className="truncate text-[12px] font-semibold text-text-secondary">{email}</p>
          <p className="text-[10.5px] font-bold uppercase tracking-wide text-text-muted">{role}</p>
        </div>
        <button
          onClick={signOut}
          className="rounded-[8px] px-2.5 py-1.5 text-left text-[12px] font-semibold text-text-muted transition hover:bg-surface hover:text-status-crit"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
