'use client';

import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { GRANT_STATUSES, MODULES, PLATFORMS } from '@/lib/constants';
import { Btn, Card, EmptyState, IconBtn, StatTile, TrashIcon } from '@/components/ui';
import type { ContentPlatform, ContentPost, Grant, Metric, Task, TaskModule } from '@/lib/types';

const METRIC_CATEGORIES = ['website', 'instagram', 'facebook', 'tiktok', 'email', 'tickets'];

export function Dashboard({ userId }: { userId: string }) {
  const supabase = useMemo(() => createClient(), []);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [content, setContent] = useState<ContentPost[]>([]);
  const [grants, setGrants] = useState<Grant[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [openForm, setOpenForm] = useState(false);

  useEffect(() => {
    Promise.all([
      supabase.from('tasks').select('*'),
      supabase.from('content_posts').select('*'),
      supabase.from('grants').select('*'),
      supabase.from('metrics').select('*'),
    ]).then(([t, c, g, m]) => {
      if (t.data) setTasks(t.data as Task[]);
      if (c.data) setContent(c.data as ContentPost[]);
      if (g.data) setGrants(g.data as Grant[]);
      if (m.data) setMetrics(m.data as Metric[]);
    });

    const channel = supabase
      .channel('dashboard-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, () => supabase.from('tasks').select('*').then(({ data }) => data && setTasks(data as Task[])))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'content_posts' }, () => supabase.from('content_posts').select('*').then(({ data }) => data && setContent(data as ContentPost[])))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'grants' }, () => supabase.from('grants').select('*').then(({ data }) => data && setGrants(data as Grant[])))
      .on('postgres_changes', { event: '*', schema: 'public', table: 'metrics' }, () => supabase.from('metrics').select('*').then(({ data }) => data && setMetrics(data as Metric[])))
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabase]);

  const openTasks = tasks.filter((t) => t.status !== 'done').length;
  const doneTasks = tasks.filter((t) => t.status === 'done').length;
  const inPipeline = content.filter((c) => c.status !== 'posted').length;
  const activeGrants = grants.filter((g) => g.status !== 'declined').length;

  const byModule = (Object.keys(MODULES) as TaskModule[])
    .map((mod) => ({
      mod,
      todo: tasks.filter((t) => t.module === mod && t.status === 'todo').length,
      doing: tasks.filter((t) => t.module === mod && t.status === 'doing').length,
      done: tasks.filter((t) => t.module === mod && t.status === 'done').length,
    }))
    .filter((r) => r.todo + r.doing + r.done > 0);

  const byPlatform = (Object.keys(PLATFORMS) as ContentPlatform[])
    .map((p) => ({ platform: p, count: content.filter((c) => c.platform === p).length }))
    .filter((r) => r.count > 0);
  const maxPlatform = Math.max(1, ...byPlatform.map((r) => r.count));

  const grantCounts = GRANT_STATUSES.map((s) => ({ ...s, count: grants.filter((g) => g.status === s.id).length }));
  const recentMetrics = [...metrics].sort((a, b) => b.period.localeCompare(a.period)).slice(0, 8);

  async function addMetric(form: FormData) {
    const draft = {
      period: String(form.get('period') || ''),
      category: String(form.get('category') || 'website'),
      metric: String(form.get('metric') || ''),
      value: Number(form.get('value') || 0),
      created_by: userId,
    };
    setOpenForm(false);
    await supabase.from('metrics').insert(draft);
  }

  async function removeMetric(id: string) {
    setMetrics((prev) => prev.filter((m) => m.id !== id));
    await supabase.from('metrics').delete().eq('id', id);
  }

  return (
    <div>
      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label="Open tasks" value={openTasks} sub={tasks.length ? `${tasks.length} total` : 'No tasks yet'} />
        <StatTile label="Tasks done" value={doneTasks} sub={tasks.length ? `${Math.round((100 * doneTasks) / tasks.length)}% of board` : ''} />
        <StatTile label="In the content pipeline" value={inPipeline} sub={content.length ? `${content.length} total posts` : 'No posts yet'} />
        <StatTile label="Grants in play" value={activeGrants} sub={grants.length ? `${grants.length} tracked` : 'No grants yet'} />
      </div>

      <div className="grid grid-cols-1 items-start gap-4 lg:grid-cols-[1.2fr_1fr]">
        <div className="flex flex-col gap-4">
          <Card title="Tasks by module" sub="To do · in progress · done, per work stream.">
            {byModule.length ? (
              <>
                {byModule.map((r) => (
                  <StackedBar
                    key={r.mod}
                    label={MODULES[r.mod].label}
                    segs={[
                      { n: r.todo, color: 'var(--status-todo)' },
                      { n: r.doing, color: 'var(--status-doing)' },
                      { n: r.done, color: 'var(--status-done)' },
                    ]}
                  />
                ))}
                <div className="mt-3 flex gap-3.5 border-t border-border pt-3 text-[11.5px] font-semibold text-text-secondary">
                  <Legend color="var(--status-todo)" label="To do" />
                  <Legend color="var(--status-doing)" label="In progress" />
                  <Legend color="var(--status-done)" label="Done" />
                </div>
              </>
            ) : (
              <EmptyState title="No tasks yet" sub="Add a task to see the breakdown by module." />
            )}
          </Card>

          <Card title="Grant pipeline" sub="Every grant tracked, by stage.">
            <div className="flex flex-wrap gap-1.5">
              {grantCounts.map((g) => (
                <div key={g.id} className="min-w-[84px] flex-1 rounded-[10px] border px-3 py-2.5 text-center" style={{ borderColor: g.border, background: g.bg, color: g.fg }}>
                  <div className="font-display text-[20px] font-extrabold tabular-nums">{g.count}</div>
                  <div className="mt-0.5 text-[10.5px] font-bold uppercase tracking-wide">{g.label}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="flex flex-col gap-4">
          <Card title="Content by platform" sub="Posts logged in the calendar.">
            {byPlatform.length ? (
              byPlatform.map((r) => (
                <div key={r.platform} className="mb-2.5 grid grid-cols-[92px_1fr_28px] items-center gap-2.5 last:mb-0">
                  <div className="text-[12px] font-bold text-text-secondary">{PLATFORMS[r.platform].label}</div>
                  <div className="flex h-3.5 overflow-hidden rounded-[5px] border border-border bg-surface-2">
                    <div className="h-full" style={{ width: `${(100 * r.count) / maxPlatform}%`, background: PLATFORMS[r.platform].color }} />
                  </div>
                  <div className="text-right text-[12px] font-bold tabular-nums text-text-muted">{r.count}</div>
                </div>
              ))
            ) : (
              <EmptyState title="No posts logged" sub="Add a post in the Content tab to see it here." />
            )}
          </Card>

          <Card title="KPI log" sub="Manual metrics — ticket sales, followers, site visits, whatever your team tracks.">
            {recentMetrics.length ? (
              <table className="w-full border-collapse text-[12.5px]">
                <thead>
                  <tr>
                    {['Period', 'Category', 'Metric', 'Value', ''].map((h) => (
                      <th key={h} className="border-b border-border px-2 py-1.5 text-left text-[10.5px] font-bold uppercase tracking-wide text-text-muted">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {recentMetrics.map((m) => (
                    <tr key={m.id}>
                      <td className="border-b border-border px-2 py-1.5">{m.period}</td>
                      <td className="border-b border-border px-2 py-1.5">{m.category}</td>
                      <td className="border-b border-border px-2 py-1.5">{m.metric}</td>
                      <td className="border-b border-border px-2 py-1.5 font-bold tabular-nums">{m.value}</td>
                      <td className="border-b border-border px-2 py-1.5">
                        <IconBtn label="Remove metric" onClick={() => removeMetric(m.id)}>
                          <TrashIcon />
                        </IconBtn>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <EmptyState title="No metrics logged yet" sub="Log ticket sales, follower counts, or site visits below." />
            )}

            {openForm ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  addMetric(new FormData(e.currentTarget));
                }}
                className="mt-2.5 grid grid-cols-2 gap-2 rounded-[10px] border border-dashed border-border-strong bg-surface-2 p-2.5"
              >
                <input name="period" required placeholder="2026-09" className="rounded-md border border-border-strong bg-surface px-2 py-1.5 text-[12.5px]" />
                <select name="category" className="rounded-md border border-border-strong bg-surface px-2 py-1.5 text-[12.5px]">
                  {METRIC_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c[0].toUpperCase() + c.slice(1)}
                    </option>
                  ))}
                </select>
                <input name="metric" required placeholder="Followers" className="rounded-md border border-border-strong bg-surface px-2 py-1.5 text-[12.5px]" />
                <input name="value" type="number" step="any" required placeholder="Value" className="rounded-md border border-border-strong bg-surface px-2 py-1.5 text-[12.5px]" />
                <div className="col-span-2 flex gap-2">
                  <Btn type="submit" variant="primary" className="text-[11.5px]">
                    Save
                  </Btn>
                  <Btn variant="ghost" className="text-[11.5px]" onClick={() => setOpenForm(false)}>
                    Cancel
                  </Btn>
                </div>
              </form>
            ) : (
              <button onClick={() => setOpenForm(true)} className="mt-2.5 w-full rounded-[9px] border border-dashed border-border-strong px-2.5 py-2 text-left text-[12px] font-bold text-text-muted transition hover:border-accent hover:bg-accent-soft hover:text-accent-strong">
                + Log a metric
              </button>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

function StackedBar({ label, segs }: { label: string; segs: { n: number; color: string }[] }) {
  const total = segs.reduce((a, s) => a + s.n, 0) || 1;
  return (
    <div className="mb-2.5 grid grid-cols-[92px_1fr_28px] items-center gap-2.5 last:mb-0">
      <div className="text-[12px] font-bold text-text-secondary">{label}</div>
      <div className="flex h-3.5 overflow-hidden rounded-[5px] border border-border bg-surface-2">
        {segs.map((s, i) => (s.n ? <div key={i} style={{ width: `${(100 * s.n) / total}%`, background: s.color }} /> : null))}
      </div>
      <div className="text-right text-[12px] font-bold tabular-nums text-text-muted">{segs.reduce((a, s) => a + s.n, 0)}</div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="h-2 w-2 rounded-[3px]" style={{ background: color }} />
      {label}
    </div>
  );
}
