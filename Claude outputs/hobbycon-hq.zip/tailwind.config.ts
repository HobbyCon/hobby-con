import type { Config } from 'tailwindcss';

// Brand tokens pulled from hobbycon.com's stylesheet (style.css :root),
// plus a status/platform system for the HQ app. Keep this file as the one
// place brand color changes get made.
const config: Config = {
  darkMode: ['class', '[data-theme="dark"]'],
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-montserrat)', 'system-ui', 'sans-serif'],
        sans: ['var(--font-public-sans)', 'system-ui', 'sans-serif'],
      },
      colors: {
        bg: 'var(--bg)',
        surface: 'var(--surface)',
        'surface-2': 'var(--surface-2)',
        border: 'var(--border)',
        text: 'var(--text)',
        'text-secondary': 'var(--text-secondary)',
        'text-muted': 'var(--text-muted)',
        accent: 'var(--accent)',
        'accent-strong': 'var(--accent-strong)',
        'accent-soft': 'var(--accent-soft)',
        status: {
          todo: 'var(--status-todo)',
          doing: 'var(--status-doing)',
          attn: 'var(--status-attn)',
          done: 'var(--status-done)',
          crit: 'var(--status-crit)',
        },
        mod: {
          vendorfair: 'var(--mod-vendorfair)',
          funding: 'var(--mod-funding)',
          content: 'var(--mod-content)',
          general: 'var(--mod-general)',
        },
        plat: {
          instagram: 'var(--plat-instagram)',
          facebook: 'var(--plat-facebook)',
          tiktok: 'var(--plat-tiktok)',
          email: 'var(--plat-email)',
        },
      },
      boxShadow: {
        sm2: 'var(--shadow-sm)',
        md2: 'var(--shadow-md)',
      },
    },
  },
  plugins: [],
};

export default config;
