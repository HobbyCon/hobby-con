// Hand-written types matching supabase/migrations/0001_init.sql.
// If you prefer generated types, run:
//   npx supabase gen types typescript --project-id YOUR_PROJECT_REF > lib/types.ts
// and re-add the domain unions below (the generator won't know them).

export type Role = 'admin' | 'member';
export type TaskModule = 'vendor-fair' | 'funding' | 'content' | 'general';
export type TaskStatus = 'todo' | 'doing' | 'done';
export type ContentPlatform = 'instagram' | 'facebook' | 'tiktok' | 'email';
export type ContentStatus = 'idea' | 'drafting' | 'scheduled' | 'posted';
export type GrantStatus = 'researching' | 'drafting' | 'submitted' | 'awarded' | 'declined';

export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  role: Role;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  module: TaskModule;
  status: TaskStatus;
  assignee: string | null;
  due_date: string | null;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ContentPost {
  id: string;
  title: string;
  platform: ContentPlatform;
  status: ContentStatus;
  scheduled_date: string | null;
  link: string | null;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface Grant {
  id: string;
  name: string;
  amount: string | null;
  deadline: string | null;
  status: GrantStatus;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface Metric {
  id: string;
  period: string;
  category: string;
  metric: string;
  value: number;
  created_by: string | null;
  created_at: string;
}

// Minimal Database shape for @supabase/ssr's generic client. This is not a
// full generated schema — it's enough for typed table() calls in this app.
export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      tasks: { Row: Task; Insert: Partial<Task>; Update: Partial<Task> };
      content_posts: { Row: ContentPost; Insert: Partial<ContentPost>; Update: Partial<ContentPost> };
      grants: { Row: Grant; Insert: Partial<Grant>; Update: Partial<Grant> };
      metrics: { Row: Metric; Insert: Partial<Metric>; Update: Partial<Metric> };
    };
  };
}
