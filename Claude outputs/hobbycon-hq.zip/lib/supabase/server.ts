import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

// Server client — used in server components, server actions, and route
// handlers. Reads/writes the auth cookie so the session survives navigation.
// See the comment in lib/supabase/client.ts for why this isn't
// parameterized with the Database type.
export function createClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: any) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch {
            // Called from a Server Component during render — safe to ignore
            // because middleware.ts refreshes the session on every request.
          }
        },
        remove(name: string, options: any) {
          try {
            cookieStore.set({ name, value: '', ...options });
          } catch {
            // See note above.
          }
        },
      },
    }
  );
}

// Admin client — service-role key, server-only. Never import this from a
// client component or a file that ships to the browser. Used exclusively by
// app/api/invite to call Supabase's admin invite-by-email API.
export function createAdminClient() {
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { cookies: { get() { return undefined; }, set() {}, remove() {} } }
  );
}
