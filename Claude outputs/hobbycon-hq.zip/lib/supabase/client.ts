'use client';

import { createBrowserClient } from '@supabase/ssr';

// Browser client — used inside client components. Reads the public anon
// key only; RLS policies (see supabase/migrations/0001_init.sql) are what
// actually gate what each signed-in user can see and change.
//
// Not parameterized with the generated Database type: lib/types.ts is a
// hand-written stand-in (see the comment there) whose shape doesn't fully
// satisfy postgrest-js's generic constraints. Call sites cast results to
// the domain types (Task, ContentPost, ...) instead — see any component's
// `.then(({ data }) => ... as Task[])`. Swap in real generated types with
// `npx supabase gen types typescript` and this can go back to
// createBrowserClient<Database>(...) for full inference.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
