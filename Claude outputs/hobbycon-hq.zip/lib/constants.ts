import type { ContentPlatform, ContentStatus, GrantStatus, TaskModule, TaskStatus } from '@/lib/types';

export const MODULES: Record<TaskModule, { label: string; fg: string; bg: string; border: string }> = {
  'vendor-fair': { label: 'Vendor Fair', fg: 'var(--mod-vendorfair)', bg: 'var(--mod-vendorfair-bg)', border: 'var(--mod-vendorfair-border)' },
  funding: { label: 'Funding', fg: 'var(--mod-funding)', bg: 'var(--mod-funding-bg)', border: 'var(--mod-funding-border)' },
  content: { label: 'Content', fg: 'var(--mod-content)', bg: 'var(--mod-content-bg)', border: 'var(--mod-content-border)' },
  general: { label: 'General', fg: 'var(--mod-general)', bg: 'var(--mod-general-bg)', border: 'var(--mod-general-border)' },
};

type StatusMeta = { id: string; label: string; fg: string; bg: string; border: string };

const STATUS_TOKENS = {
  todo: { fg: 'var(--status-todo)', bg: 'var(--status-todo-bg)', border: 'var(--status-todo-border)' },
  doing: { fg: 'var(--status-doing)', bg: 'var(--status-doing-bg)', border: 'var(--status-doing-border)' },
  attn: { fg: 'var(--status-attn)', bg: 'var(--status-attn-bg)', border: 'var(--status-attn-border)' },
  done: { fg: 'var(--status-done)', bg: 'var(--status-done-bg)', border: 'var(--status-done-border)' },
  crit: { fg: 'var(--status-crit)', bg: 'var(--status-crit-bg)', border: 'var(--status-crit-border)' },
};

export const TASK_STATUSES: Array<StatusMeta & { id: TaskStatus }> = [
  { id: 'todo', label: 'To do', ...STATUS_TOKENS.todo },
  { id: 'doing', label: 'In progress', ...STATUS_TOKENS.doing },
  { id: 'done', label: 'Done', ...STATUS_TOKENS.done },
];

export const CONTENT_STATUSES: Array<StatusMeta & { id: ContentStatus }> = [
  { id: 'idea', label: 'Idea', ...STATUS_TOKENS.todo },
  { id: 'drafting', label: 'Drafting', ...STATUS_TOKENS.doing },
  { id: 'scheduled', label: 'Scheduled', ...STATUS_TOKENS.attn },
  { id: 'posted', label: 'Posted', ...STATUS_TOKENS.done },
];

export const GRANT_STATUSES: Array<StatusMeta & { id: GrantStatus }> = [
  { id: 'researching', label: 'Researching', ...STATUS_TOKENS.todo },
  { id: 'drafting', label: 'Drafting', ...STATUS_TOKENS.doing },
  { id: 'submitted', label: 'Submitted', ...STATUS_TOKENS.attn },
  { id: 'awarded', label: 'Awarded', ...STATUS_TOKENS.done },
  { id: 'declined', label: 'Declined', ...STATUS_TOKENS.crit },
];

export const PLATFORMS: Record<ContentPlatform, { label: string; color: string }> = {
  instagram: { label: 'Instagram', color: 'var(--plat-instagram)' },
  facebook: { label: 'Facebook', color: 'var(--plat-facebook)' },
  tiktok: { label: 'TikTok', color: 'var(--plat-tiktok)' },
  email: { label: 'Email / newsletter', color: 'var(--plat-email)' },
};

export function statusMeta<T extends { id: string }>(list: T[], id: string): T {
  return list.find((s) => s.id === id) ?? list[0];
}

export function fmtDate(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function monthKey(iso: string | null): string {
  if (!iso) return 'No date';
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d.getTime())) return 'No date';
  return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
