# HobbyCon HQ

Internal team workspace for HobbyCon: tasks, a social content calendar, and
the grant funding pipeline, with a lightweight analytics dashboard on top.
Next.js (App Router) + Supabase (Postgres, Auth, Realtime) + Tailwind,
deployed on Vercel.

Branding (colors, Montserrat, the gradient wordmark) is pulled from
`hobbycon.com`'s own stylesheet — see `app/globals.css` and
`tailwind.config.ts` for the single source of truth if the site's palette
changes.

## Access model

- **Invite-only.** There's no public sign-up. An admin invites a teammate by
  email from the in-app Team page; Supabase emails them a magic sign-in
  link.
- **Roles: Admin / Member.** Both can create and edit tasks, content posts,
  grants, and metrics. Only admins can delete other people's items, invite
  or remove teammates, and change roles. See the RLS policies in
  `supabase/migrations/0001_init.sql` for the exact rules — that file is the
  actual source of truth for permissions, not the app code.
- **Realtime.** Every open tab subscribes to Postgres changes, so when one
  teammate drags a task or logs a metric, everyone else sees it update
  immediately.

## One-time setup

1. **Create a Supabase project** (supabase.com → New project). Note the
   project URL and anon key from Project Settings → API, and the
   `service_role` key (keep this one secret).

2. **Run the schema.** Paste `supabase/migrations/0001_init.sql` into the
   Supabase SQL Editor and run it. This creates the tables, the
   admin/member role system, row-level security policies, Realtime
   publication, and seeds a few known HobbyCon planning items (the
   vendor-fair venue/permitting tasks and the Amber Grant / HerRise / IFundWomen
   pipeline).

3. **Turn off public sign-up.** Authentication → Providers → Email → turn
   off "Allow new users to sign up." This is what makes the workspace
   invite-only — without it, anyone with the link could create an account.

4. **Create the first admin.** Sign in once (Authentication → Users → Add
   user → invite by email, using your own address) so your `profiles` row
   exists, then in the SQL Editor run:
   ```sql
   update public.profiles set role = 'admin' where email = 'you@hobbycon.com';
   ```
   Every admin after that can be promoted from the in-app Team page — no
   more manual SQL needed.

5. **Environment variables.** Copy `.env.local.example` to `.env.local` for
   local dev, and set the same three keys in Vercel → Project → Settings →
   Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server-only — used by `/api/invite` and
     `/api/team` to send invites and remove users; never exposed to the
     browser)

6. **Deploy.** Push this repo to GitHub, then in Vercel: New Project →
   import the repo → it auto-detects Next.js → add the env vars above →
   Deploy. In Supabase, add the deployed URL (and `http://localhost:3000`
   for local dev) under Authentication → URL Configuration → Redirect URLs,
   as `<your-url>/auth/callback`.

7. **Invite the team.** Sign in as the admin, go to `/team`, and invite each
   teammate by email. They'll get a magic-link email; first click signs
   them in and creates their profile as a Member.

## Local development

```bash
npm install
cp .env.local.example .env.local   # fill in your Supabase keys
npm run dev
```

## Project structure

```
app/
  login/                 magic-link sign-in
  auth/callback/         exchanges the email link for a session
  (app)/                 authenticated shell (sidebar) + the four modules
    dashboard/  tasks/  content/  grants/  team/
  api/
    invite/               admin-only: POST to invite a teammate by email
    team/                 admin-only: PATCH role, DELETE a teammate
components/               one client component per module (realtime + CRUD)
lib/
  supabase/               browser / server / admin Supabase clients
  types.ts                hand-written types matching the SQL schema
  constants.ts            status/module/platform labels + brand color tokens
supabase/migrations/      schema, RLS policies, seed data
```

## Extending it

- **Analytics connectors.** The KPI log on the dashboard is manual entry by
  design — no live analytics connector was wired in yet. If you connect a
  Google Analytics / Meta / TikTok data source later (e.g. via Supabase Edge
  Functions or a scheduled job), have it write into the `metrics` table on
  the same shape the manual form uses, and the dashboard picks it up with
  no UI changes.
- **More roles.** If "Everyone equal" or a read-only Viewer tier ever
  becomes necessary, the RLS policies in the migration are the only place
  that needs to change — the UI already reads `role` off `profiles`.
